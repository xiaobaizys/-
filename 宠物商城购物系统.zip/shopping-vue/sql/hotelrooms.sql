/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50720 (5.7.20-log)
 Source Host           : localhost:3306
 Source Schema         : hotelrooms

 Target Server Type    : MySQL
 Target Server Version : 50720 (5.7.20-log)
 File Encoding         : 65001

 Date: 17/11/2023 17:42:44
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for orderinfo
-- ----------------------------
DROP TABLE IF EXISTS `orderinfo`;
CREATE TABLE `orderinfo`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `ordernumber` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单编号',
  `roomnumber` int(11) NOT NULL COMMENT '房间号码',
  `fullname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '宾客姓名',
  `checkindate` datetime NOT NULL COMMENT '入住日期',
  `sumprice` int(10) NOT NULL COMMENT '总金额',
  `paystatus` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '支付状态',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 64 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of orderinfo
-- ----------------------------
INSERT INTO `orderinfo` VALUES (32, 'f3f99c40da7', 5010, '112233', '2023-05-13 17:36:37', 8888, '已支付', '1');
INSERT INTO `orderinfo` VALUES (30, '5820d2e03a1', 2009, '222', '2023-10-20 17:28:50', 368, '未支付', '111');
INSERT INTO `orderinfo` VALUES (31, '5e7200d5dae', 5005, '4444', '2023-11-13 17:35:51', 8888, '未支付', '1');
INSERT INTO `orderinfo` VALUES (28, '392c35735be', 1001, '李先生', '2023-09-13 16:51:56', 288, '已支付', '无');
INSERT INTO `orderinfo` VALUES (29, '47a23446c7a', 1001, 'aaa', '2023-11-15 17:21:25', 288, '已支付', '111');
INSERT INTO `orderinfo` VALUES (59, '03c34d10d5b', 11, '有啊呀', '2023-11-06 00:00:00', 666, '已支付', 'hh');
INSERT INTO `orderinfo` VALUES (60, 'b43ce0507ec', 1111, 'zzz', '2023-11-17 00:00:00', 111, '已支付', 'hh');
INSERT INTO `orderinfo` VALUES (58, '23303115026', 123, '名字', '2023-11-09 00:00:00', 199, '未支付', '77');
INSERT INTO `orderinfo` VALUES (57, '4d80f2b4f98', 123, 'zzz', '2023-11-10 00:00:00', 100, '未支付', '啥东西啊');

-- ----------------------------
-- Table structure for registrationinfo
-- ----------------------------
DROP TABLE IF EXISTS `registrationinfo`;
CREATE TABLE `registrationinfo`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `roomnumber` int(11) NOT NULL COMMENT '房间号码',
  `roomtype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '房间类型',
  `price` int(11) NOT NULL COMMENT '房间价格',
  `fullname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '住户姓名',
  `userid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '身份证号码',
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '住户手机号码',
  `checkindate` datetime NOT NULL COMMENT '入住日期',
  `days` int(11) NOT NULL COMMENT '入住天数',
  `deposit` int(11) NOT NULL COMMENT '预收押金',
  `sumprice` int(11) NOT NULL COMMENT '合计金额',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 31 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of registrationinfo
-- ----------------------------
INSERT INTO `registrationinfo` VALUES (20, 1001, '宠物食品', 288, '李建成', '452627200013987265', '19330418888', '2023-08-16 17:14:40', 1, 500, 788, '无');
INSERT INTO `registrationinfo` VALUES (21, 1001, '宠物食品', 288, 'aaa', '111111111111111111', '19330418898', '2023-10-26 17:27:55', 1, 500, 788, '111');
INSERT INTO `registrationinfo` VALUES (22, 2009, '宠物玩具', 368, '222', '111111111111111111', '19330418857', '2023-11-13 17:28:50', 1, 500, 868, '111');
INSERT INTO `registrationinfo` VALUES (24, 5010, '宠物医疗用品', 8888, '112233', '222222222222222222', '19330418756', '2023-02-15 17:36:37', 1, 500, 9388, '1');
INSERT INTO `registrationinfo` VALUES (25, 2008, '宠物玩具', 368, '王大锤', '555555555555555555', '19330418535', '2023-11-13 17:37:59', 2, 500, 1236, '22');
INSERT INTO `registrationinfo` VALUES (26, 4003, '宠物用品', 698, 'aaaa', '555555555555555555', '19330418857', '2023-11-13 17:38:51', 1, 500, 1198, '1');
INSERT INTO `registrationinfo` VALUES (27, 4007, '宠物用品', 698, 'yy', '434324444444444444', '19330418755', '2023-11-13 17:39:52', 1, 500, 1198, '1');
INSERT INTO `registrationinfo` VALUES (28, 3008, '宠物用品', 588, 'dd', '454543532423434234', '19330418857', '2023-11-13 17:40:37', 1, 500, 1088, '1');
INSERT INTO `registrationinfo` VALUES (29, 1006, '宠物用品', 288, 'uu', '898988988989889989', '19330418857', '2023-11-13 21:28:41', 1, 500, 788, '1');
INSERT INTO `registrationinfo` VALUES (30, 2003, '宠物玩具', 368, 'zz', '343434325453434322', '19330415698', '2023-11-13 21:29:19', 1, 500, 868, '1');

-- ----------------------------
-- Table structure for roomsinfo
-- ----------------------------
DROP TABLE IF EXISTS `roomsinfo`;
CREATE TABLE `roomsinfo`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `roomnumber` int(11) NOT NULL COMMENT '房间号码',
  `roomtype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '房间类型',
  `price` int(11) NULL DEFAULT NULL COMMENT '房间价格',
  `bedtype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '床型',
  `wlantype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '宽带类型',
  `deposit` int(11) NULL DEFAULT NULL COMMENT '押金标准',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `roomnumber`(`roomnumber`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 54 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of roomsinfo
-- ----------------------------
INSERT INTO `roomsinfo` VALUES (1, 1001, '宠物食品', 999, '加餐', '出售', 500, '无');
INSERT INTO `roomsinfo` VALUES (2, 1002, '宠物医疗用品', 288, '不加餐', '未售', 500, '无');
INSERT INTO `roomsinfo` VALUES (3, 1003, '宠物用品', 100, '加餐', '未售', 500, '无');
INSERT INTO `roomsinfo` VALUES (4, 1004, '宠物食品', 2139, '不加餐', '出售', 500, '无');
INSERT INTO `roomsinfo` VALUES (5, 1005, '宠物玩具', 288, '加餐', '未售', 500, '无');
INSERT INTO `roomsinfo` VALUES (6, 1006, '宠物食品', 243, '不加餐', '未售', 500, '无');
INSERT INTO `roomsinfo` VALUES (7, 1007, '宠物用品', 288, '加餐', '出售', 500, '无');
INSERT INTO `roomsinfo` VALUES (8, 1008, '宠物玩具', 4365, '不加餐', '未售', 500, '无');
INSERT INTO `roomsinfo` VALUES (9, 1009, '宠物食品', 288, '加餐', '出售', 500, '无');
INSERT INTO `roomsinfo` VALUES (10, 1010, '宠物医疗用品', 66, '不加餐', '未售', 500, '无');
INSERT INTO `roomsinfo` VALUES (53, 1111, '宠物医疗用品', 45, '不加餐', '未售', 343, '部署');

-- ----------------------------
-- Table structure for roomstatusinfo
-- ----------------------------
DROP TABLE IF EXISTS `roomstatusinfo`;
CREATE TABLE `roomstatusinfo`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `roomnumber` int(11) NOT NULL COMMENT '房间号码',
  `roomtype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '房间类型',
  `price` int(11) NOT NULL COMMENT '房间价格',
  `fullname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '入住客户',
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '手机号码',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '房间状态',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 62 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of roomstatusinfo
-- ----------------------------
INSERT INTO `roomstatusinfo` VALUES (10, 1001, '宠物食品', 288, '李先生', '19330418898', '待收货', '111');
INSERT INTO `roomstatusinfo` VALUES (9, 1002, '宠物用品', 288, '', '', '待收货', '');
INSERT INTO `roomstatusinfo` VALUES (8, 1003, '宠物食品', 288, '121', '19330415555', '待发货', '1');
INSERT INTO `roomstatusinfo` VALUES (7, 1004, '宠物用品', 288, '', '', '待支付', '');
INSERT INTO `roomstatusinfo` VALUES (6, 1005, '宠物医疗用品', 288, '212', '19330415555', '待发货', '1');
INSERT INTO `roomstatusinfo` VALUES (11, 1006, '宠物玩具', 288, 'uu', '19330418857', '待发货', '1');
INSERT INTO `roomstatusinfo` VALUES (12, 1007, '宠物医疗用品', 288, '', '', '待支付', '');
INSERT INTO `roomstatusinfo` VALUES (13, 1008, '宠物玩具', 288, '王大', '19330415555', '待发货', '1');
INSERT INTO `roomstatusinfo` VALUES (14, 1009, '宠物玩具', 288, '', '', '待收货', '');

-- ----------------------------
-- Table structure for userinfo
-- ----------------------------
DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE `userinfo`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `account` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '账号',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '密码',
  `fullname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '姓名',
  `sex` enum('男','女','保密') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '性别',
  `role` enum('超级管理员','管理员','普通用户') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '普通用户' COMMENT '角色',
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '手机号',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '邮箱',
  `status` enum('禁用','启用') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '状态',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of userinfo
-- ----------------------------
INSERT INTO `userinfo` VALUES (1, 'admin', '123456', '李先生', '男', '超级管理员', '15992236609', 'zys6606@163.com', '启用', '无');
INSERT INTO `userinfo` VALUES (3, 'user1', '123456', '张三', '女', '管理员', '13812345678', 'user1@qq.com', '启用', '这是用户1的备注');
INSERT INTO `userinfo` VALUES (5, 'user2', '123456', '王五', '保密', '普通用户', '13666666666', 'user2@example.com', '启用', '这是用户2的备注');
INSERT INTO `userinfo` VALUES (6, 'user3', '123456', '赵六', '女', '普通用户', '13999999999', 'user3@example.com', '启用', '这是用户3的备注');
INSERT INTO `userinfo` VALUES (8, 'user4', '123456', '孙八', '男', '普通用户', '13333333333', 'user4@example.com', '禁用', '这是用户4的备注');
INSERT INTO `userinfo` VALUES (9, 'user5', '123456', '周九', '女', '普通用户', '13222222222', 'user5@example.com', '启用', '这是用户5的备注');
INSERT INTO `userinfo` VALUES (10, 'zys', '123456', 'xiaobai', '男', '超级管理员', '15992236606', 'zys6606@163.com', '启用', '123');
INSERT INTO `userinfo` VALUES (11, 'adminss', '123456', 'zzz', '女', '超级管理员', '15992236609', 'zys66@163.com', '启用', 'hh');

-- ----------------------------
-- View structure for view_order
-- ----------------------------
DROP VIEW IF EXISTS `view_order`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `view_order` AS select date_format(`months`.`month`,'%c月') AS `month`,coalesce(sum(`hotelrooms`.`orderinfo`.`sumprice`),0) AS `totalprice` from (((select ('2023-01-01' + interval (`numbers`.`n` - 1) month) AS `month` from (select 1 AS `n` union select 2 AS `2` union select 3 AS `3` union select 4 AS `4` union select 5 AS `5` union select 6 AS `6` union select 7 AS `7` union select 8 AS `8` union select 9 AS `9` union select 10 AS `10` union select 11 AS `11` union select 12 AS `12`) `numbers`)) `months` left join `hotelrooms`.`orderinfo` on(((month(`hotelrooms`.`orderinfo`.`checkindate`) = month(`months`.`month`)) and (year(`hotelrooms`.`orderinfo`.`checkindate`) = year(`months`.`month`))))) group by `months`.`month` order by `months`.`month`;

-- ----------------------------
-- View structure for view_roomstatus
-- ----------------------------
DROP VIEW IF EXISTS `view_roomstatus`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `view_roomstatus` AS select `roomstatusinfo`.`roomtype` AS `roomtype`,sum((case when (`roomstatusinfo`.`status` = '空闲') then 1 else 0 end)) AS `vacant`,sum((case when (`roomstatusinfo`.`status` = '入住') then 1 else 0 end)) AS `occupied`,sum((case when (`roomstatusinfo`.`status` = '清洁') then 1 else 0 end)) AS `cleaned` from `roomstatusinfo` group by `roomstatusinfo`.`roomtype`;

-- ----------------------------
-- View structure for view_roomtype
-- ----------------------------
DROP VIEW IF EXISTS `view_roomtype`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `view_roomtype` AS select `registrationinfo`.`roomtype` AS `roomtype`,sum(`registrationinfo`.`price`) AS `total_price` from `registrationinfo` where (year(`registrationinfo`.`checkindate`) = 2023) group by `registrationinfo`.`roomtype`;

SET FOREIGN_KEY_CHECKS = 1;
