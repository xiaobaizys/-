<template>
 <div>
  <el-carousel :interval="5000" arrow="always">
    <el-carousel-item v-for="item in images" :key="item.src">
      <img class="image" :src="item" alt="">
    </el-carousel-item>
  </el-carousel>
  <div class="" id="box">
		<ul>
			<li v-for="item in list">
				<img v-bind:src="item.src" alt="">
				<h3>{{item.des}}</h3>
        <span>{{ item.text }}</span>
				<p>￥{{item.price}}</p>
			</li>
		</ul>
	</div>
 </div>
</template>

<script>
export default{
  data() {
    return {
      images:[
      require('../assets/content9.gif'),
        require('../assets/content6.jpg'),
        require('../assets/content7.jpg'),
        require('../assets/content8.jpg')

      ],
      list:[
						{
							src:'https://img2.epetbar.com/common/upload/commonfile/2020/09/23/095559_726454.jpg',
							des:'顽皮Wanpy 醇香牛肉棒 400g',
              text:'精选牛肉 18道工序加工 低温风干 原质原味 醇香美味',
							price:14.90
						},
            {
							src:'https://img2.epetbar.com/2018-04/28/11/0dc4e258f419b84dda0afcce38223f49.jpg',
							des:'路斯 奶酪牛肉棒狗零食 200g',
              text:'干燥有嚼劲 磨牙解馋 营养美味 训练奖励  ',
							price:11.90
						},
            {
							src:'https://img2.epetbar.com/common/upload/commonfile/2019/12/02/144050_296553.jpg',
							des:'小佩PETKIT 智能饮水机3代 可容量1.35L',
              text:'四重净化系统 软化水质 防干烧保护 智能加热 W型水路循环	  ',
							price:14.90
						},
            {
							src:'https://img2.epetbar.com/common/upload/commonfile/2022/08/17/0105245_533953.jpg',
							des:'犬心保 驱虫牛肉块 L 体重23-45kg 6粒/盒',
              text:' 每月一次 有效驱除蛔虫/心丝虫/钩虫 牛肉粒更易喂食  ',
							price:229.90
						},
            {
							src:'https://img2.epetbar.com/2018-01/30/10/d6572833427e158a14d9658048e63aa7.jpg',
							des:'麦富迪 北美原野鸭肉干 奖励零食 360g',
              text:'纯鸭胸肉 选材新鲜 训练/奖励零食',
							price:24.90
						},


            {
							src:'https://img2.epetbar.com/common/upload/commonfile/2022/05/20/110059_237719.jpg',
							des:'拜耳Bayer 拜宠清 犬用体内驱虫药 6片装',
              text:'本品仅用于2KG以上的宠物犬  ',
							price:30.90
						}
					]

    }
  },
}
</script>
<style>
  .el-carousel__item h3 {
    color: #475669;
    font-size: 18px;
    opacity: 0.75;
    line-height: 300px;
    margin: 0;
  }

  .image{
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  #box{
    padding: 20px 0;
  }

  #box ul{
		display: flex;
		flex-wrap: wrap;
	}
	#box li{
    widows: 250px;
		padding: 8px;
		list-style: none;
		margin-right: 25px;
    margin-bottom: 20px;
		border: 1px solid #eee;
    background-color: #ffffff;
    cursor: grab;
    border-radius: 5px;
	}
  #box li:hover{
    /* opacity: 0.5; */
     transition: 0.7s linear;
    transform: rotate(0deg);
      box-shadow: 0 0 3px rgba(0, 0, 0, .4);
      opacity: 0.7;
      border-radius: 5px;
  }
  /* #box li  */
	#box img{
		width: 200px;
		height: 150px;

  }
</style>
