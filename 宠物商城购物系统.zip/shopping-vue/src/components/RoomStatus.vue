<template>
  <div class="container">
    <el-tag>商品状态信息管理界面</el-tag><br />
    <el-form :inline="true" class="query-form">
      <el-form-item label="商品状态">
        <el-select v-model="queryText" placeholder="请选择" style="width: 100%;">
          <el-option label="请选择" value=""></el-option>
          <el-option label="待支付" value="待支付"></el-option>
          <el-option label="待发货" value="待发货"></el-option>
          <el-option label="待收货" value="待收货"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="handleQuery" plain>查询</el-button>
      </el-form-item>
    </el-form>
    <!--
        <el-button type="primary" class="add-button" @click="showAddDialog">
            新增
        </el-button>
 -->
    <el-table :data="filteredData" border class="center-table">
      <!-- 表格列 -->
      <el-table-column label="编号" width="60">
        <template slot-scope="scope">
          <!-- 使用 v-for 指令和索引显示编号 -->
          <span :index="scope.$index + 1">{{ scope.$index + 1 }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="roomnumber" label="标识"></el-table-column>
      <el-table-column prop="roomtype" label="商品类型"></el-table-column>
      <el-table-column prop="price" label="价格"></el-table-column>
      <el-table-column prop="fullname" label="客户姓名"></el-table-column>
      <el-table-column prop="phone" label="手机号码"></el-table-column>
      <el-table-column prop="status" label="商品状态">
        <template slot-scope="scope">
          <span v-if="scope.row.status === '待支付'"><el-tag type="success">待支付</el-tag></span>
          <span v-else-if="scope.row.status === '待发货'"><el-tag type="danger">待发货</el-tag></span>
          <span v-else-if="scope.row.status === '待收货'"><el-tag type="warning">待收货</el-tag></span>
          <span v-else>{{ scope.row.status }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="remark" label="备注"></el-table-column>

      <!-- 编辑按钮列 -->
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button type="primary" plain size="small" @click="showEditDialog(scope.row)">
            编辑
          </el-button>
          <el-button type="success" plain size="small" @click="resetContent(scope.row)">
            一键退款
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination style="margin-top: 20px;" :current-page="currentPage" :page-size="pageSize" :total="totalRows" @current-change="handlePageChange"></el-pagination>

    <!-- 新增弹窗 -->
    <el-dialog title="新增房间状态信息" :visible="isAddDialogVisible" :scrollable="false" @close="resetAddDialog" width="800px">
      <el-form ref="addRoomStatus" :model="addRoomStatus" label-width="80px" style="padding: 0px 50px;">
        <el-form-item label="房间号码" required>
          <el-select v-model="addRoomStatus.roomnumber" style="width: 100%;">
            <el-option v-for="room in rooms" :key="room.roomnumber" :label="room.roomnumber + '（' + room.roomtype + ' ￥' + room.price + '）'" :value="room.roomnumber"> </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="商品类型" required>
          <el-input v-model="addRoomStatus.roomtype" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="商品价格">
          <el-input v-model="addRoomStatus.price" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="客户姓名" required>
          <el-input v-model="addRoomStatus.fullname"></el-input>
        </el-form-item>
        <el-form-item label="手机号码" required>
          <el-input v-model="addRoomStatus.phone"></el-input>
        </el-form-item>
        <el-form-item label="商品状态" required>
          <el-select v-model="addRoomStatus.status" placeholder="请选择" style="width: 100%;">
            <el-option label="待支付" value="待支付"></el-option>
            <el-option label="待发货" value="待发货"></el-option>
            <el-option label="待收货" value="待收货"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="addRoomStatus.remark"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="resetAddDialog">取消</el-button>
        <el-button type="primary" @click="handleAdd">提交</el-button>
      </div>
    </el-dialog>

    <!-- 编辑弹窗 -->
    <el-dialog title="编辑房间状态信息" :visible="isEditDialogVisible" :scrollable="false" @close="resetEditDialog" width="800px">
      <el-form ref="editRoomStatus" :model="editRoomStatus" label-width="80px" style="padding: 0px 50px;">
        <el-form-item label="房间号码" required>
          <el-select v-model="editRoomStatus.roomnumber" style="width: 100%;" :disabled="true">
            <el-option v-for="room in rooms" :key="room.roomnumber" :label="room.roomnumber + '（' + room.roomtype + ' ￥' + room.price + '）'" :value="room.roomnumber"> </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="商品类型" required>
          <el-input v-model="editRoomStatus.roomtype" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="商品价格">
          <el-input v-model="editRoomStatus.price" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="客户姓名" required>
          <el-input v-model="editRoomStatus.fullname"></el-input>
        </el-form-item>
        <el-form-item label="手机号码" required>
          <el-input v-model="editRoomStatus.phone"></el-input>
        </el-form-item>
        <el-form-item label="商品状态" required>
          <el-select v-model="editRoomStatus.status" placeholder="请选择" style="width: 100%;">
            <el-option label="待支付" value="待支付"></el-option>
            <el-option label="待发货" value="待发货"></el-option>
            <el-option label="待收货" value="待收货"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="editRoomStatus.remark"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="resetEditDialog">取消</el-button>
        <el-button type="primary" @click="handleEdit">提交</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      queryText: '', // 查询关键字
      rooms: [],
      tableData: [], // 所有数据
      filteredData: [], // 过滤后的数据
      isAddDialogVisible: false, // 新增弹窗是否显示
      isEditDialogVisible: false, // 编辑弹窗是否显示
      addRoomStatus: {
        roomnumber: '',
        roomtype: '',
        price: '',
        fullname: '',
        phone: '',
        status: '',
        remark: ''
      },
      editRoomStatus: {
        // 编辑表单数据
        roomnumber: '',
        roomtype: '',
        price: '',
        fullname: '',
        phone: '',
        status: '',
        remark: ''
      },
      currentPage: 1, // 当前页码
      pageSize: 10, // 每页显示的行数
      totalRows: 0 // 总行数
    }
  },
  mounted() {
    if (!localStorage.getItem('users')) {
      this.$router.push('/')
      this.$message({
        message: '用户未登录！非法操作！',
        type: 'error'
      })
    }
    //获取房间信息
    axios
      .get('http://localhost:8888/rooms/get')
      .then(response => {
        this.rooms = response.data
      })
      .catch(error => {
        console.error(error)
      })
    this.getData() // 在页面加载时触发获取数据的方法
  },
  computed: {
    selectedRoom: function() {
      return this.rooms.find(room => room.roomnumber === this.addRoomStatus.roomnumber)
    }
  },
  watch: {
    'addRoomStatus.roomnumber': function(newRoomNumber) {
      const selectedRoom = this.rooms.find(room => room.roomnumber === newRoomNumber)
      if (selectedRoom) {
        this.addRoomStatus.roomtype = selectedRoom.roomtype
        this.addRoomStatus.price = selectedRoom.price
      }
    }
  },
  methods: {
    getData() {
      // 发送请求获取数据，例如使用axios或其他方式
      axios
        .get('http://localhost:8888/roomstatus/get')
        .then(response => {
          // 处理请求成功情况
          console.log('获取数据成功')
          this.tableData = response.data // 将获取到的数据赋值给tableData
          this.totalRows = this.tableData.length // 设置总行数
          this.filteredData = this.tableData.slice((this.currentPage - 1) * this.pageSize, this.currentPage * this.pageSize) // 初始化filteredData，根据当前页码和每页显示的行数进行切片
        })
        .catch(error => {
          // 处理请求错误
          console.error(error)
        })
    },
    handleQuery() {
      if (this.queryText === '') {
        this.getData()
      }
      this.filteredData = this.tableData.filter(item => {
        return item.status.includes(this.queryText)
      })
    },

    showAddDialog() {
      this.isAddDialogVisible = true // 显示新增弹窗
    },

    resetAddDialog() {
      this.isAddDialogVisible = false
      this.addRoomStatus = {}
    },

    handleAdd() {
      if (!this.addRoomStatus.roomnumber || !this.addRoomStatus.roomtype || !this.addRoomStatus.price || !this.addRoomStatus.fullname || !this.addRoomStatus.phone || !this.addRoomStatus.status) {
        this.$message({
          type: 'error',
          message: '必填项不能为空！'
        })
        return false
      }

      if (!/^1[3456789]\d{9}$/.test(this.addRoomStatus.phone)) {
        this.$message({
          type: 'error',
          message: '请输入正确的手机号！'
        })
        return false
      }

      const rooms = this.tableData.some(item => item.roomnumber === this.addRoomStatus.roomnumber)
      if (rooms) {
        this.$message({
          type: 'error',
          message: '房间号已存在！请选择新的房间号！'
        })
        return false
      }

      axios
        .post('http://localhost:8888/roomstatus/add', this.addRoomStatus)
        .then(response => {
          // 处理新增成功情况
          this.$message({
            type: 'success',
            message: '新增成功！'
          })

          this.getData()
          this.isAddDialogVisible = false
          // 刷新数据

          this.handleQuery()
          this.getData()
          // 关闭弹窗
          this.resetAddDialog()
        })
        .catch(error => {
          // 处理请求错误
          console.error(error)
        })
    },

    showEditDialog(row) {
      this.editRoomStatus = Object.assign({}, row) // 将当前行的数据复制到编辑表单
      this.isEditDialogVisible = true // 显示编辑弹窗
    },

    resetEditDialog() {
      this.isEditDialogVisible = false
      this.$refs.editRooms.resetFields() // 重置编辑表单
    },

    handleEdit() {
      axios
        .put(`http://localhost:8888/roomstatus/update/${this.editRoomStatus.id}`, this.editRoomStatus)
        .then(response => {
          this.$message({
            type: 'success',
            message: '操作成功！'
          })
          this.getData()
          this.handleQuery()
          // 关闭弹窗
          this.resetEditDialog()
        })
        .catch(error => {
          // 处理请求错误
          console.error(error)
        })
    },

    resetContent(row) {
      let restRoom = {
        roomnumber: row.roomnumber,
        roomtype: row.roomtype,
        price: row.price,
        fullname: '',
        phone: '',
        status: '清洁',
        remark: ''
      }

      axios
        .put(`http://localhost:8888/roomstatus/update/${row.id}`, restRoom)
        .then(response => {
          this.$message({
            type: 'success',
            message: '一键退房成功！'
          })
          this.getData()
          this.handleQuery()
          // 关闭弹窗
          this.resetEditDialog()
        })
        .catch(error => {
          // 处理请求错误
          console.error(error)
        })
    },

    handlePageChange(currentPage) {
      this.currentPage = currentPage // 更新当前页码
      this.filteredData = this.tableData.slice((this.currentPage - 1) * this.pageSize, this.currentPage * this.pageSize) // 根据新的页码进行数据切片
    }
  }
}
</script>

<style>
.container {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.add-button {
  margin-bottom: 10px;
}

.query-form .el-form-item {
  margin-right: 10px;
}

.el-table .warning-row {
  background: oldlace;
}

.el-table .success-row {
  background: #f0f9eb;
}

.center-table .cell {
  text-align: center;
}
</style>
